#include <QApplication>

#include "Form.h"

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);

    Form frm;
    frm.show();

    return a.exec();
}
