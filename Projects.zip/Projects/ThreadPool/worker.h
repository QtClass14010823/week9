#ifndef WORKER_H
#define WORKER_H

#include <QObject>
#include <QRunnable>

class MyTask : public QRunnable
{
    void run() override;
};

#endif // WORKER_H
