#include "Form.h"

#include <QThreadPool>

Form::Form(QWidget *parent) : QWidget(parent)
{
    layout = new QHBoxLayout(this);
    btn1 = new QPushButton("Counting numbers");
    btn2 = new QPushButton("Terminate");

    layout->addWidget(btn1);
    layout->addWidget(btn2);

    connect(btn1, &QPushButton::clicked, this, &Form::onBtn1Clicked);
    connect(btn2, &QPushButton::clicked, this, &Form::onBtn2Clicked);

    QThreadPool::globalInstance()->setMaxThreadCount(10);
}

Form::~Form()
{
}

void Form::onBtn1Clicked()
{
    MyTask *task = new MyTask;
    // QThreadPool takes ownership and deletes 'hello' automatically
    QThreadPool::globalInstance()->start(task);
}

void Form::onBtn2Clicked()
{
    MyTask *task = new MyTask;
    // QThreadPool takes ownership and deletes 'hello' automatically
    QThreadPool::globalInstance()->start(task);
}
