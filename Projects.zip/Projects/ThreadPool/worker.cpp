#include "worker.h"

#include <QDebug>
#include <QThread>

void MyTask::run()
{
    /* ... here is the expensive or blocking operation ... */
    for (int i = 0; i < 10000000; i++)
    {
        qDebug() << i;

        //QThread::sleep(1);
    }
}
